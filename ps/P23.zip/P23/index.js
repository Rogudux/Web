const express = require('express')
const app = express()
const port = 81



app.get('/', (req, res) => {

    let producto = [
        {
            nombre: "Producto 1",
            precio: 3004
        },
        {
            nombre: "Producto 2",
            precio: 3003

        }
    ];

    let htmContent = '<table border="1" width = "100%">';
    producto.forEach((producto, indice)=>{
        htmContent += `

        <tr>
            <td> >${producto.nombre} </td>
            <td> >${producto.precio} </td>
        </tr>

        `
    });

  res.send(htmContent);

})

app.listen(port, () => {
  console.log(`En puerto ${port}`)
})
